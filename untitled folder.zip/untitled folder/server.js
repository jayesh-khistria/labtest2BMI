const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());

// MongoDB connection setup
mongoose.connect('http://127.0.0.1:3000', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Define BMI Entry schema and model
const userEntrySchema = new mongoose.Schema({
  userId: { type: String, required: true },
  height: Number,
  weight: Number,
  timestamp: { type: Date, default: Date.now },
});
const UserEntry = mongoose.model('UserEntry', userEntrySchema);

// Endpoint to add user entry (record weight and height)
app.post('/addEntry', async (req, res) => {
  const { userId, height, weight } = req.body;

  try {
    const newEntry = new UserEntry({ userId, height, weight });
    await newEntry.save();
    res.json({ message: 'Entry added successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Error saving entry to the database.' });
    console.error(err);
  }
});

// Endpoint to get user's BMI data
app.get('/userAverages/:userId', async (req, res) => {
  const userId = req.params.userId;

  try {
    const userEntries = await UserEntry.find({ userId });
    const count = userEntries.length;
    const totalWeight = userEntries.reduce((acc, entry) => acc + entry.weight, 0);
    const totalHeight = userEntries.reduce((acc, entry) => acc + entry.height, 0);

    const averageWeight = count > 0 ? totalWeight / count : 0;
    const averageHeight = count > 0 ? totalHeight / count : 0;

    const averageBMI = count > 0 ? (averageWeight / (averageHeight * averageHeight)) : 0;

    res.json({ userId, averageWeight, averageHeight, averageBMI });
  } catch (err) {
    res.status(500).json({ error: 'Error fetching user data.' });
    console.error(err);
  }
});

// Endpoint to get all users' BMI data
app.get('/userStats', async (req, res) => {
  try {
    const allUsersData = await UserEntry.aggregate([
      {
        $group: {
          _id: '$userId',
          highestWeight: { $max: '$weight' },
          lowestWeight: { $min: '$weight' },
        },
      },
    ]);

    res.json(allUsersData);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching all users data.' });
    console.error(err);
  }
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
